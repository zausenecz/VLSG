Unpack archive and run install.bat

Use VLSG for regular launch from desctop
Use VLSG Client when launching from Riot client